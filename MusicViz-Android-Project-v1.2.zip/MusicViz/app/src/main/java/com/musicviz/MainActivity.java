package com.musicviz;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Visualizer;
import android.media.audiofx.Equalizer;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.util.ArrayList;
import java.io.*;

public class MainActivity extends Activity {
    private LinearLayout page;
    private TextView trackInfo, status, playButton;
    private ImageView coverView;
    private VisualizerView visualizerView;
    private MediaPlayer player;
    private Visualizer visualizer;
    private BassBoost bassBoost;
    private Equalizer equalizer;
    private final ArrayList<File> tracks = new ArrayList<>();
    private int current = 0;
    private boolean bassEnabled = false;
    private boolean playing = false;
    private int visualMode = 0; // 0 bars, 1 waveform, 2 mirror
    private int visualColor = 0; // cyan, violet, green
    private float sensitivity = 1.0f;
    private static final int PICK_AUDIO = 10, PICK_VIZ = 11;
    private File musicDir, presetDir;

    private int bg = Color.rgb(8, 10, 18);
    private int panel = Color.rgb(20, 25, 40);
    private int accent() {
        if (visualColor == 1) return Color.rgb(178, 105, 255);
        if (visualColor == 2) return Color.rgb(65, 230, 150);
        return Color.rgb(0, 205, 255);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(0);
        }
        musicDir = new File(getFilesDir(), "music");
        presetDir = new File(getFilesDir(), "presets");
        musicDir.mkdirs(); presetDir.mkdirs();
        refreshLibrary();
        buildUi();
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 30);
        }
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String value, boolean primary) {
        Button b = new Button(this);
        b.setText(value); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackground(shape(primary ? accent() : Color.rgb(35, 43, 63), 22));
        b.setPadding(12, 4, 12, 4);
        return b;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }
    private void addGap(LinearLayout target, int height) {
        View v = new View(this); target.addView(v, lp(1, height));
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        page = vertical();
        page.setPadding(18, 12, 18, 24);
        page.setBackgroundColor(bg);

        // Top navigation row: always visible at the top of the screen.
        LinearLayout top = vertical();
        LinearLayout brandRow = horizontal();
        TextView brand = text("MUSIC", 22, Color.WHITE, true);
        TextView brand2 = text("VIZ", 22, accent(), true);
        LinearLayout brandBox = horizontal();
        brandBox.addView(brand); brandBox.addView(brand2);
        brandRow.addView(brandBox, new LinearLayout.LayoutParams(-1, 48));
        top.addView(brandRow);
        LinearLayout navRow = horizontal();
        Button libraryTop = button("Библиотека", false);
        Button editorTop = button("Редактор", false);
        navRow.addView(libraryTop, new LinearLayout.LayoutParams(0, 46, 1));
        LinearLayout.LayoutParams navEditor = new LinearLayout.LayoutParams(0, 46, 1);
        navEditor.leftMargin = 8;
        navRow.addView(editorTop, navEditor);
        top.addView(navRow);
        page.addView(top);
        libraryTop.setOnClickListener(v -> showLibrary());
        editorTop.setOnClickListener(v -> showEditor());

        TextView subtitle = text("ТВОЯ МУЗЫКА. ТВОЙ ВИЗУАЛ.", 11, Color.LTGRAY, true);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, lp(-1, 30));

        // Album artwork card.
        LinearLayout artCard = vertical();
        artCard.setPadding(14, 14, 14, 14);
        artCard.setBackground(shape(panel, 28));
        coverView = new ImageView(this);
        coverView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        coverView.setBackground(shape(Color.rgb(28, 42, 65), 22));
        LinearLayout.LayoutParams cp = lp(-1, 230);
        artCard.addView(coverView, cp);
        trackInfo = text("Выбери или импортируй трек", 19, Color.WHITE, true);
        trackInfo.setGravity(Gravity.CENTER);
        trackInfo.setPadding(4, 14, 4, 2);
        artCard.addView(trackInfo, lp(-1, 48));
        status = text("Локальная библиотека готова", 12, Color.LTGRAY, false);
        status.setGravity(Gravity.CENTER);
        artCard.addView(status, lp(-1, 28));
        LinearLayout.LayoutParams ap = lp(-1, -2); ap.topMargin = 12;
        page.addView(artCard, ap);

        visualizerView = new VisualizerView();
        LinearLayout.LayoutParams vp = lp(-1, 190); vp.topMargin = 14;
        page.addView(visualizerView, vp);

        // Playback transport controls.
        LinearLayout controls = horizontal();
        controls.setGravity(Gravity.CENTER);
        Button prev = button("⏮", false);
        playButton = text("▶", 25, Color.WHITE, true);
        playButton.setGravity(Gravity.CENTER);
        playButton.setBackground(shape(accent(), 60));
        Button next = button("⏭", false);
        controls.addView(prev, lp(68, 58));
        LinearLayout.LayoutParams pp = lp(82, 64); pp.setMargins(18, 0, 18, 0);
        controls.addView(playButton, pp);
        controls.addView(next, lp(68, 58));
        LinearLayout.LayoutParams ctrlp = lp(-1, 76); ctrlp.topMargin = 8;
        page.addView(controls, ctrlp);
        prev.setOnClickListener(v -> changeTrack(-1));
        next.setOnClickListener(v -> changeTrack(1));
        playButton.setOnClickListener(v -> togglePlayback());

        Button importAudio = button("＋  Импортировать аудиофайлы", true);
        LinearLayout.LayoutParams imp = lp(-1, 52); imp.topMargin = 8;
        page.addView(importAudio, imp);
        importAudio.setOnClickListener(v -> pick("audio/*", PICK_AUDIO));

        LinearLayout tools = horizontal();
        Button bass = button(bassEnabled ? "Бас: ВКЛ" : "Бас: ВЫКЛ", false);
        Button editor = button("Настроить визуализацию", false);
        tools.addView(bass, new LinearLayout.LayoutParams(0, 50, 1));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, 50, 1); ep.leftMargin = 8;
        tools.addView(editor, ep);
        LinearLayout.LayoutParams tp = lp(-1, 54); tp.topMargin = 8;
        page.addView(tools, tp);
        bass.setOnClickListener(v -> {
            bassEnabled = !bassEnabled;
            bass.setText(bassEnabled ? "Бас: ВКЛ" : "Бас: ВЫКЛ");
            applyBass();
        });
        editor.setOnClickListener(v -> showEditor());

        LinearLayout vizTools = horizontal();
        Button switchViz = button("Сменить визуализацию", false);
        Button myViz = button("Мои пресеты", false);
        vizTools.addView(switchViz, new LinearLayout.LayoutParams(0, 50, 1));
        LinearLayout.LayoutParams mvp = new LinearLayout.LayoutParams(0, 50, 1); mvp.leftMargin = 8;
        vizTools.addView(myViz, mvp);
        LinearLayout.LayoutParams vtp = lp(-1, 54); vtp.topMargin = 8;
        page.addView(vizTools, vtp);
        switchViz.setOnClickListener(v -> cycleVisualization());
        myViz.setOnClickListener(v -> showPresets());

        Button importViz = button("＋  Импортировать из Avee Player (.viz)", false);
        LinearLayout.LayoutParams zp = lp(-1, 48); zp.topMargin = 8;
        page.addView(importViz, zp);
        importViz.setOnClickListener(v -> pick("application/octet-stream", PICK_VIZ));

        Button playlist = button("Импортировать ссылку на плейлист Яндекса", false);
        LinearLayout.LayoutParams plp = lp(-1, 48); plp.topMargin = 8;
        page.addView(playlist, plp);
        playlist.setOnClickListener(v -> importYandexPlaylistLink());

        Button yandex = button("Открыть Яндекс Музыку", false);
        LinearLayout.LayoutParams yp = lp(-1, 50); yp.topMargin = 8;
        page.addView(yandex, yp);
        yandex.setOnClickListener(v -> openYandex());

        TextView disclaimer = text("Яндекс Музыка открывается отдельно. Защищённые офлайн-загрузки нельзя импортировать в сторонний плеер. Импортируй обычные MP3, FLAC, WAV и другие доступные аудиофайлы. Файлы .viz пока сохраняются как пресеты; полная совместимость с движком Avee не заявляется.", 11, Color.rgb(170, 180, 198), false);
        disclaimer.setPadding(4, 12, 4, 8);
        page.addView(disclaimer, lp(-1, -2));

        scroll.addView(page);
        setContentView(scroll);
        showFallbackCover();
    }


    private void cycleVisualization() {
        visualMode = (visualMode + 1) % 3;
        if (visualizerView != null) visualizerView.invalidate();
        String[] names = {"Эквалайзер", "Волна", "Зеркальный эквалайзер"};
        status.setText("Визуализация: " + names[visualMode]);
    }

    private void showPresets() {
        File[] files = presetDir == null ? null : presetDir.listFiles();
        ArrayList<File> presets = new ArrayList<>();
        if (files != null) for (File f : files) if (f.isFile()) presets.add(f);
        if (presets.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Мои пресеты")
                .setMessage("Пока нет импортированных файлов. Добавь .viz через кнопку импорта.")
                .setPositiveButton("Импортировать", (d,w) -> pick("application/octet-stream", PICK_VIZ))
                .setNegativeButton("Закрыть", null).show();
            return;
        }
        String[] names = new String[presets.size()];
        for (int i = 0; i < presets.size(); i++) names[i] = presets.get(i).getName();
        new AlertDialog.Builder(this).setTitle("Импортированные пресеты")
            .setItems(names, (d, which) -> new AlertDialog.Builder(this)
                .setTitle(presets.get(which).getName())
                .setMessage("Файл сохранён в MusicViz. Для применения произвольного пресета Avee нужен совместимый движок; пока доступны встроенные режимы визуализации.")
                .setPositiveButton("Сменить встроенный эффект", (dd,ww) -> cycleVisualization())
                .setNegativeButton("Удалить", (dd,ww) -> {
                    presets.get(which).delete();
                    status.setText("Пресет удалён");
                }).setNeutralButton("Закрыть", null).show())
            .setNegativeButton("Закрыть", null).show();
    }

    private void importYandexPlaylistLink() {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setHint("https://music.yandex.ru/users/.../playlists/...");
        String saved = getPreferences(MODE_PRIVATE).getString("yandex_playlist_url", "");
        field.setText(saved);
        new AlertDialog.Builder(this).setTitle("Ссылка на плейлист Яндекс Музыки")
            .setMessage("Ссылка сохранится в MusicViz. Можно открыть плейлист в Яндексе, а собственные доступные аудиофайлы импортировать отдельно. Защищённые треки из подписки не копируются.")
            .setView(field)
            .setPositiveButton("Сохранить ссылку", (d,w) -> {
                String value = field.getText().toString().trim();
                if (!(value.startsWith("https://music.yandex.") || value.startsWith("https://yandex.ru/"))) {
                    status.setText("Введи действительную ссылку Яндекс Музыки");
                    return;
                }
                getPreferences(MODE_PRIVATE).edit().putString("yandex_playlist_url", value).apply();
                status.setText("Ссылка на плейлист сохранена");
                new AlertDialog.Builder(this).setMessage("Ссылка сохранена. Открыть плейлист в Яндекс Музыке?")
                    .setPositiveButton("Открыть", (dd,ww) -> {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value))); }
                        catch (Exception e) { status.setText("Не удалось открыть ссылку"); }
                    }).setNegativeButton("Позже", null).show();
            }).setNegativeButton("Отмена", null).show();
    }

    private void showFallbackCover() {
        Bitmap bitmap = Bitmap.createBitmap(700, 500, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bitmap);
        Paint p = new Paint(3);
        p.setShader(new LinearGradient(0, 0, 700, 500, new int[]{Color.rgb(16, 34, 62), accent(), Color.rgb(20, 12, 38)}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 700, 500, p);
        p.setShader(null); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD)); p.setTextSize(74);
        c.drawText("MUSICVIZ", 350, 245, p);
        p.setTextSize(24); p.setTypeface(Typeface.DEFAULT);
        c.drawText("YOUR SOUND • YOUR VISUAL", 350, 292, p);
        coverView.setImageBitmap(bitmap);
    }
    private void updateCover(File file) {
        try {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            r.setDataSource(file.getAbsolutePath());
            byte[] art = r.getEmbeddedPicture();
            r.release();
            if (art != null) {
                Bitmap b = BitmapFactory.decodeByteArray(art, 0, art.length);
                if (b != null) { coverView.setImageBitmap(b); return; }
            }
        } catch (Exception ignored) {}
        showFallbackCover();
    }

    private void pick(String type, int request) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType(type); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, request == PICK_AUDIO);
        startActivityForResult(i, request);
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == PICK_AUDIO) {
            int imported = 0;
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++)
                    if (copyIntoLibrary(data.getClipData().getItemAt(i).getUri())) imported++;
            } else if (data.getData() != null && copyIntoLibrary(data.getData())) imported++;
            refreshLibrary();
            status.setText("Импортировано файлов: " + imported);
            if (!tracks.isEmpty() && imported > 0) playTrack(Math.max(0, tracks.size() - imported));
        } else if (req == PICK_VIZ && data.getData() != null) savePreset(data.getData());
    }
    private boolean copyIntoLibrary(Uri uri) {
        String name = getName(uri).replaceAll("[^a-zA-Z0-9._() -]", "_");
        if (name.trim().isEmpty()) name = "audio_" + System.currentTimeMillis();
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : ".audio";
        File target = new File(musicDir, name); int n = 1;
        while (target.exists()) target = new File(musicDir, stem + "_" + (n++) + ext);
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
            if (in == null) return false;
            byte[] buf = new byte[16384]; int count;
            while ((count = in.read(buf)) != -1) out.write(buf, 0, count);
            out.flush(); return target.length() > 0;
        } catch (Exception e) {
            if (target.exists()) target.delete();
            status.setText("Ошибка импорта: " + e.getMessage()); return false;
        }
    }
    private String getName(Uri uri) {
        String name = "audio_" + System.currentTimeMillis();
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0 && c.getString(ix) != null) name = c.getString(ix);
            }
        } catch (Exception ignored) {}
        return name;
    }
    private void refreshLibrary() {
        tracks.clear();
        File[] files = musicDir == null ? null : musicDir.listFiles();
        if (files != null) for (File f : files) if (f.isFile() && f.length() > 0) tracks.add(f);
        java.util.Collections.sort(tracks, (a,b) -> a.getName().compareToIgnoreCase(b.getName()));
    }
    private void showLibrary() {
        refreshLibrary();
        if (tracks.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Моя библиотека")
                .setMessage("Библиотека пока пуста. Импортируй обычные аудиофайлы.")
                .setPositiveButton("Понятно", null).show(); return;
        }
        String[] names = new String[tracks.size()];
        for (int i = 0; i < tracks.size(); i++) names[i] = (i + 1) + ". " + tracks.get(i).getName();
        new AlertDialog.Builder(this).setTitle("Моя музыка • " + tracks.size())
            .setItems(names, (d, which) -> {
                current = which; playTrack(which);
                new AlertDialog.Builder(this).setTitle(tracks.get(which).getName())
                    .setMessage("Трек хранится в приватной библиотеке MusicViz.")
                    .setPositiveButton("Слушать", (dd,w) -> playTrack(which))
                    .setNegativeButton("Удалить", (dd,w) -> {
                        if (player != null && current == which) releasePlayer();
                        tracks.get(which).delete(); refreshLibrary();
                        status.setText("Удалено из библиотеки"); trackInfo.setText("Выбери трек");
                        showFallbackCover(); updatePlayButton();
                    }).setNeutralButton("Закрыть", null).show();
            }).setNegativeButton("Закрыть", null).show();
    }
    private void playTrack(int index) {
        refreshLibrary();
        if (tracks.isEmpty()) { status.setText("Библиотека пуста"); return; }
        current = (index + tracks.size()) % tracks.size();
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setDataSource(tracks.get(current).getAbsolutePath());
            player.setOnPreparedListener(mp -> {
                mp.start(); playing = true;
                trackInfo.setText(tracks.get(current).getName());
                status.setText("Локальная копия • " + (current + 1) + " из " + tracks.size());
                updatePlayButton(); updateCover(tracks.get(current)); attachEffects();
            });
            player.setOnCompletionListener(mp -> changeTrack(1));
            player.setOnErrorListener((mp, what, extra) -> {
                playing = false; updatePlayButton(); status.setText("Не удалось воспроизвести этот файл"); return true;
            });
            player.prepareAsync();
            status.setText("Загрузка трека…");
        } catch (Exception e) { status.setText("Ошибка воспроизведения: " + e.getMessage()); }
    }
    private void updatePlayButton() {
        if (playButton != null) playButton.setText(playing ? "Ⅱ" : "▶");
    }
    private void togglePlayback() {
        if (player == null) {
            refreshLibrary();
            if (!tracks.isEmpty()) playTrack(current);
            else pick("audio/*", PICK_AUDIO);
        } else if (playing) {
            try { player.pause(); } catch (Exception ignored) {}
            playing = false; status.setText("Пауза"); updatePlayButton();
        } else {
            try { player.start(); playing = true; status.setText("Воспроизведение"); updatePlayButton(); }
            catch (Exception e) { status.setText("Нажми на трек в библиотеке"); }
        }
    }
    private void changeTrack(int delta) {
        refreshLibrary();
        if (!tracks.isEmpty()) playTrack(current + delta);
    }
    private void attachEffects() {
        try {
            int id = player.getAudioSessionId();
            visualizer = new Visualizer(id);
            visualizer.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
            visualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                public void onWaveFormDataCapture(Visualizer v, byte[] data, int rate) { visualizerView.setWave(data); }
                public void onFftDataCapture(Visualizer v, byte[] data, int rate) { visualizerView.setFft(data); }
            }, Visualizer.getMaxCaptureRate() / 2, true, true);
            visualizer.setEnabled(true); applyBass();
        } catch (Exception e) { status.setText("Визуализатор недоступен на этом устройстве"); }
    }
    private void applyBass() {
        try {
            if (player == null) return;
            int id = player.getAudioSessionId();
            if (bassBoost != null) bassBoost.release();
            bassBoost = new BassBoost(0, id); bassBoost.setEnabled(bassEnabled);
            if (bassEnabled) bassBoost.setStrength((short) 800);
            if (equalizer != null) equalizer.release();
            equalizer = new Equalizer(0, id); equalizer.setEnabled(bassEnabled);
            if (bassEnabled && equalizer.getNumberOfBands() > 0) {
                short band = (short)(equalizer.getNumberOfBands() - 1);
                short[] range = equalizer.getBandLevelRange();
                equalizer.setBandLevel(band, range[1]);
            }
        } catch (Exception ignored) {}
    }
    private void showEditor() {
        LinearLayout box = vertical(); box.setPadding(20, 12, 20, 4);
        TextView modeLabel = text("Стиль визуализации", 15, Color.WHITE, true);
        box.addView(modeLabel);
        Spinner mode = new Spinner(this);
        String[] modes = {"Эквалайзер", "Волна", "Зеркальный эквалайзер"};
        mode.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        mode.setSelection(visualMode); box.addView(mode, lp(-1, 48));
        TextView colorLabel = text("Цвет", 15, Color.WHITE, true);
        box.addView(colorLabel);
        Spinner colors = new Spinner(this);
        String[] colorNames = {"Неоновый голубой", "Фиолетовый", "Изумрудный"};
        colors.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, colorNames));
        colors.setSelection(visualColor); box.addView(colors, lp(-1, 48));
        TextView sensLabel = text("Чувствительность: " + String.format(java.util.Locale.US, "%.1f", sensitivity) + "×", 15, Color.WHITE, true);
        box.addView(sensLabel);
        SeekBar sens = new SeekBar(this); sens.setMax(20); sens.setProgress((int)((sensitivity - 0.5f) * 20));
        sens.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int value, boolean user) {
                sensLabel.setText("Чувствительность: " + String.format(java.util.Locale.US, "%.1f", 0.5f + value / 20f) + "×");
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        box.addView(sens, lp(-1, 48));
        new AlertDialog.Builder(this).setTitle("Редактор визуализации")
            .setView(box)
            .setPositiveButton("Сохранить", (d,w) -> {
                visualMode = mode.getSelectedItemPosition();
                visualColor = colors.getSelectedItemPosition();
                sensitivity = 0.5f + sens.getProgress() / 20f;
                visualizerView.invalidate();
                status.setText("Настройки визуализации применены");
            }).setNegativeButton("Отмена", null).show();
    }
    private void openYandex() {
        Intent i = getPackageManager().getLaunchIntentForPackage("ru.yandex.music");
        if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.yandex.ru/"));
        try { startActivity(i); status.setText("Открыта Яндекс Музыка"); }
        catch (Exception e) { status.setText("Не удалось открыть Яндекс Музыку"); }
    }
    private void savePreset(Uri uri) {
        String sourceName = getName(uri);
        String safe = sourceName.replaceAll("[^a-zA-Z0-9._() -]", "_");
        if (!safe.toLowerCase(java.util.Locale.ROOT).endsWith(".viz")) {
            status.setText("Выбери файл пресета с расширением .viz");
            return;
        }
        File target = new File(presetDir, safe);
        int suffix = 1;
        String stem = safe.substring(0, safe.length() - 4);
        while (target.exists()) target = new File(presetDir, stem + "_" + (suffix++) + ".viz");
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(target)) {
            if (in == null) throw new IOException("Файл недоступен");
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
            if (target.length() == 0) throw new IOException("Файл пустой");
            status.setText("Пресет сохранён: " + target.getName());
        } catch (Exception e) {
            if (target.exists()) target.delete();
            status.setText("Ошибка импорта пресета: " + e.getMessage());
        }
    }
    private void releasePlayer() {
        try { if (visualizer != null) { visualizer.setEnabled(false); visualizer.release(); } } catch (Exception ignored) {}
        visualizer = null;
        try { if (bassBoost != null) bassBoost.release(); } catch (Exception ignored) {}
        try { if (equalizer != null) equalizer.release(); } catch (Exception ignored) {}
        bassBoost = null; equalizer = null;
        if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; }
        playing = false; updatePlayButton();
    }
    @Override protected void onDestroy() { releasePlayer(); super.onDestroy(); }

    class VisualizerView extends View {
        private byte[] fft = new byte[0], wave = new byte[0];
        private final Paint p = new Paint(3);
        public VisualizerView() { super(MainActivity.this); setBackground(shape(panel, 24)); }
        void setFft(byte[] b) { fft = b.clone(); postInvalidate(); }
        void setWave(byte[] b) { wave = b.clone(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            p.setShader(null); p.setColor(Color.rgb(42, 50, 68)); p.setStrokeWidth(1);
            for (int y = 1; y < 4; y++) c.drawLine(12, h*y/4, w-12, h*y/4, p);
            p.setColor(accent());
            if (visualMode == 1 && wave.length > 1) {
                p.setStrokeWidth(3); p.setStyle(Paint.Style.STROKE);
                float step = w / (float)wave.length;
                for (int i=1;i<wave.length;i++) {
                    float y1 = h/2 - ((wave[i-1] & 255)-128) * sensitivity * h/300f;
                    float y2 = h/2 - ((wave[i] & 255)-128) * sensitivity * h/300f;
                    c.drawLine((i-1)*step, y1, i*step, y2, p);
                }
                p.setStyle(Paint.Style.FILL);
            } else {
                int count = Math.max(1, Math.min(fft.length/2, 70));
                float bar = (w-24) / count;
                for (int i=0;i<count;i++) {
                    int raw = fft.length > i*2+1 ? (fft[i*2+1] & 255) : 0;
                    float value = (float)Math.pow(raw/255f, 1.25) * h * .78f * sensitivity;
                    float x = 12 + i*bar;
                    if (visualMode == 2) {
                        c.drawRoundRect(x+1, h/2-value/2, x+bar-2, h/2+value/2, bar/3, bar/3, p);
                    } else {
                        c.drawRoundRect(x+1, h-value-8, x+bar-2, h-8, bar/3, bar/3, p);
                    }
                }
            }
            if (fft.length == 0 && wave.length == 0) {
                p.setColor(Color.LTGRAY); p.setTextSize(14); p.setTextAlign(Paint.Align.CENTER);
                c.drawText("ВИЗУАЛИЗАЦИЯ", w/2, h/2, p);
                p.setTextSize(11); c.drawText("Запусти трек, чтобы увидеть реакцию на музыку", w/2, h/2+22, p);
            }
        }
    }
}
